package aula13;

public enum TipoLocalidade {
	Cidade,Vila,Aldeia
}
