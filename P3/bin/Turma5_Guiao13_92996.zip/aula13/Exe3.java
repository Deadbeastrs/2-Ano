package aula13;

public class Exe3 {
	public static void main(String[] args) {
		BrincaBeira b = new BrincaBeira();
		b.addFunc("Diogo");
		b.addFunc("Gui");
		b.addFunc("Luis");
		b.addFunc("Luisa");
		b.addFunc("Rainho");
		b.addFunc("Joao");
		b.addFunc("Miguel");
		b.addFunc("Clara Pedro");
		b.addFunc("Clara Joao");
		b.addFunc("Clara Diogo");
		b.addFunc("Clara Manel");
		b.genBrinquedo();
		b.nomeToToy();
		b.getPopularNames();
		b.trocarIngressos();
		b.trocarIngressos();
	}
}
