package aula05;

public interface Policia {
	String getTipo();
	double getID();
}
