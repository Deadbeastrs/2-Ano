package aula05;

public interface Motorizado {
	double getPotencia();
	double getConsumo();
	String getCombustivel();
}
