package aula08;

import java.io.IOException;

public class QQSM {
	public static void main(String[] args) throws IOException {
		QQSMGame game = new QQSMGame();
	}
}
