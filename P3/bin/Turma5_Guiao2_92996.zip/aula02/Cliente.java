package aula02;

public class Cliente {
	private String name;
	private int cc;
	private Date nascDate;
	private int nMec;
	private String curso;
	private int nFunc;
	private int nf;
	private int nSocio;
	private Date dataInsc;
	private int maxVid;
	
	public Cliente(int nSocio, Date dataInsc,int maxVid, String name, int cc, Date ndate, int nmec, String curso) {
		this.name = name;
		this.cc = cc;
		this.nascDate = ndate;
		this.nMec = nmec;
		this.curso = curso;
		this.nSocio = nSocio;
		this.dataInsc = dataInsc;
		this.maxVid = maxVid;
	}

	public Cliente(int nSocio, Date dataInsc,int maxVid, String name, int cc, Date ndate, int nFunc, int nf ) {
		this.name = name;
		this.cc = cc;
		this.nascDate = ndate;
		this.nFunc = nFunc;
		this.nf = nf;
		this.nSocio = nSocio;
		this.dataInsc = dataInsc;
		this.maxVid = maxVid;
	}
	
	public int getId() {
		return this.nSocio;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void subVid() {
		this.maxVid = this.maxVid - 1;
	}
	
	public int getMaxVid() {
		return this.maxVid;
	}
	
	public String toString() {
		return "Numero de sócio=" + nSocio + ", Data de Inscricao=" + dataInsc.showData() + " Nome: " + name;
	}
}
