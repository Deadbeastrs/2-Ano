package aula02;

public class Ponto {
	private int x;
	private int y;
	
	public Ponto(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public int xval() {
		return this.x;
	}
	
	public int yval() {
		return this.y;
	}
}
