package aula11;

public interface Vegetariano {

}
