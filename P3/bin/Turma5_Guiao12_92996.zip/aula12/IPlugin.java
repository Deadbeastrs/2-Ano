package aula12;

public interface IPlugin {
	public void fazQualQuerCoisa ();
}
