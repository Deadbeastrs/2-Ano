package aula12;

public class Plugin2 implements IPlugin{

	@Override
	public void fazQualQuerCoisa() {
		System.out.println("Rodrigo");
	}
	
}
