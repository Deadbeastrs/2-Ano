package aula12;

public class Pugin1 implements IPlugin{

	@Override
	public void fazQualQuerCoisa() {
		System.out.println("Diogo");
	}

}
