package aula06;

public interface Vegetariano {

}
