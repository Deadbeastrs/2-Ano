package aula09;

public interface Iterator {
	boolean hasNext();
	Object next();
	void remove();
}
