package aula09;

public interface Gelado {
	public void base(int n);
}
